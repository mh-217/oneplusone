# Ubuntu Touch for Oneplus One

###How to install:
http://wiki.ubports.com/index.php/OnePlus_One

###How to build:
http://wiki.ubports.com/index.php/OnePlus_One_Build

###What is working?
http://wiki.ubports.com/index.php/OnePlus_One#What_works

###Forum:
http://forums.ubports.com/forumdisplay.php?fid=7
