Device tree for One+One

Copyright 2016, The CyanogenMod Project

